function sol(){
document.getElementById("clima").src = "img/sol.jpg"
}
function chuva(){
    document.getElementById("clima").src = "img/chuva.jpg"
    }